/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package aula7;

import static aula7.Trio.min;

/**
 *
 * @author udesc
 */
public class Aula7 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Trio caso1 = new Trio("oi", 2, "!@");
        Trio caso2 = new Trio(3,4,5);
        Trio caso3 = new Trio(199, 2, "!wafohdfa");
        Trio caso4 = new Trio(0, 200, "lçrehkpeo!");
        
        caso1.setFirst(13);
        System.out.println(caso1);
        
        int result = min(caso1,caso2);
        System.out.println(result);
    }
    
}
