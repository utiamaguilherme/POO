/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package aula7;

/**
 *
 * @author udesc
 * @param <T>
 */
public class Trio<T extends Comparable> {
    private T first;
    private T second;
    private T third;
    public Trio(T first, T second, T third){
        this.first = first;
        this.second = second;
        this.third = third;
    }

    /**
     * @return the first
     */
    public T getFirst() {
        return first;
    }

    /**
     * @param first the first to set
     */
    public void setFirst(T first) {
        this.first = first;
    }

    /**
     * @return the second
     */
    public T getSecond() {
        return second;
    }

    /**
     * @param second the second to set
     */
    public void setSecond(T second) {
        this.second = second;
    }

    /**
     * @return the third
     */
    public T getThird() {
        return third;
    }

    /**
     * @param third the third to set
     */
    public void setThird(T third) {
        this.third = third;
    }
    
    public static int max(Trio obj1, Trio obj2){
        if(obj1.first.compareTo(obj2.first) > 0)        return (int)obj1.first;
        else if(obj1.first.compareTo(obj2.first) < 0)   return (int)obj2.first;
        if(obj1.second.compareTo(obj2.second) > 0)      return (int)obj1.second;
        else if(obj1.second.compareTo(obj2.second) < 0) return (int)obj2.second;
        if(obj1.third.compareTo(obj2.third) > 0 )       return (int)obj1.third;
        else if(obj1.third.compareTo(obj2.third) < 0 )       return (int)obj2.third;
        else return -1;
    }
    public static int min(Trio obj1, Trio obj2){
        if(obj1.first.compareTo(obj2.first) < 0)        return (int)obj1.first;
        else if(obj1.first.compareTo(obj2.first) > 0)   return (int)obj2.first;
        if(obj1.second.compareTo(obj2.second) < 0)      return (int)obj1.second;
        else if(obj1.second.compareTo(obj2.second) > 0) return (int)obj2.second;
        if(obj1.third.compareTo(obj2.third) < 0 )       return (int)obj1.third;
        else if(obj1.third.compareTo(obj2.third) > 0 )       return (int)obj2.third;
        else return -1;
    }
}
