/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication1;

/**
 *
 * @author udesc
 */
public class Triangulo {
    
    private double a;
    private double b;
    private double c;
    
    Triangulo(double b, double c, double a){
        if(Math.abs(b-c) < a && a < b+c){
            if(Math.abs(a-c) < b && b < a+c){
                if(Math.abs(a-b) < c && c < a+b){
                    this.a = a;
                    this.b = b;
                    this.c = c;
                }else
                    System.out.println("Nao formou triangulo");
            }else
                System.out.println("Nao formou triangulo");
        }else
            System.out.println("Nao formou triangulo");
    }
    
    Triangulo(double a, double b){
        this.a = a;
        this.b = b;
        this.c = Math.sqrt(a*a+b*b);
    }
    
    
    
}
