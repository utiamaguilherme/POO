/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication1;
import java.util.Scanner;
/**
 *
 * @author udesc
 */
public class JavaApplication1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        Scanner scan = new Scanner(System.in);
        Fibonacci f = new Fibonacci(189273);
        f.show(-5, 999);
        
        //Fim da questao 1
        System.out.println("---------------------------------------");
        //Inicio da questao 2
        String a, b;
        a = "EI2O";
        b = "2S97";
        
        char[] values = {'I','E','O','S'};
        char[] new_values = {'1','3','0','5'};
        
        for(int i=0; i<4; i++){
            a = a.replace(values[i], new_values[i]);
            b = b.replace(values[i], new_values[i]);
        }
        
        int res = Integer.parseInt(a) + Integer.parseInt(b);
        String sres = Integer.toString(res);
        
        for(int i=0; i<4; i++)
            sres = sres.replace(new_values[i], values[i]);
        
        System.out.println(sres);
        //Fim da questao 2
        System.out.println("---------------------------------------");
        //Inicio da questao 3
        
    }
    
}
