/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication1;

/**
 *
 * @author udesc
 */
public class Vetor2D {
    private final Ponto2D a;
    private final Ponto2D b;
    private final double modulo;
    private final double[] vetor = new double[2];
    
    Vetor2D(double x, double y, double x1, double y1){
        this.a = new Ponto2D(x, y);
        this.b = new Ponto2D(x1, y1);
        modulo = a.getModulo(b);
        vetor[0] = Math.abs(a.getX() - b.getX());
        vetor[1] = Math.abs(b.getY() - a.getY());
    }
    
    public Vetor2D soma(Vetor2D other){
        double x = vetor[0] + other.vetor[0];
        double y = vetor[1] + other.vetor[1];
        Vetor2D resultante = new Vetor2D(this.vetor[0], this.vetor[1], 
                                         other.vetor[0], other.vetor[1]);
        resultante.vetor[0] = x;
        resultante.vetor[1] = y;
        return resultante;
    }
    
    public double getAngulo(){
        return Math.acos(vetor[0] / Math.sqrt(vetor[0]*vetor[0] + vetor[1]*vetor[1]));
    }
    
    public double[] getVetor(){
        return this.vetor;
    }
    
    public double getModulo(){
        return this.modulo;
    }
}
