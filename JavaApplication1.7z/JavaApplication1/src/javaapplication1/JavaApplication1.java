/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication1;
import java.util.Scanner;
/**
 *
 * @author udesc
 */
public class JavaApplication1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        Scanner scan = new Scanner(System.in);
        Vetor2D[] vetores = new Vetor2D[3];
        for(int i=0; i<2; i++){
            double x,x1,y,y1;
            x = scan.nextDouble();
            y = scan.nextDouble();
            x1= scan.nextDouble();
            y1= scan.nextDouble();
            vetores[i] = new Vetor2D(x,y,x1,y1);
        }
        
        vetores[2] = vetores[0].soma(vetores[1]);
        
        for(Vetor2D each : vetores){
            double[] vetor = each.getVetor();
            System.out.println("Vetor: ("+ vetor[0] +","+vetor[1]+")");
            System.out.println("Modulo: "+each.getModulo());
            System.out.println("Angulo: "+each.getAngulo());
        }
        
    }
    
}
